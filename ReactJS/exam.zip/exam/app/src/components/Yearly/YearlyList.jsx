import React, { Component } from 'react';

export default class YearlyBalanceList extends Component{
    constructor(props){
        super(props);

        this.state = {
            balance: {},
            year: 0
        };
    }
    render(){
        return(
            <div class="container">
            <div class="row space-top">
                <div class="col-md-12">
                    <h1>Yearly Balance</h1>
                </div>
            </div>
            <div class="row space-top col-md-12">
                <div class="col-md-3">
                    <div class="card text-white bg-secondary">
                        <div class="card-body">
                            <blockquote class="card-blockquote">
                                <h2>November</h2>
                                <h4>Year 2017</h4>
                                <label for="budget">Budget:</label>
                                <input class="col-md-9" name="budget" disabled/>
                                <label for="balance">Balance:</label>
                                <input class="col-md-9" name="balance" disabled/>
                                <div class="space-top">
                                    <a href="monthly.html" class="btn btn-secondary">Details</a>
                                </div>
                            </blockquote>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-white bg-secondary">
                        <div class="card-body">
                            <blockquote class="card-blockquote">
                                <h2>December</h2>
                                <h4>Year 2017</h4>
                                <label for="budget">Budget:</label>
                                <input class="col-md-9" name="budget" disabled/>
                                <label for="balance">Balance:</label>
                                <input class="col-md-9" name="balance" disabled/>
                                <div class="space-top">
                                    <a href="monthly.html" class="btn btn-secondary">Details</a>
                                </div>
                            </blockquote>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-white bg-secondary">
                        <div class="card-body">
                            <blockquote class="card-blockquote">
                                <h2>January</h2>
                                <h4>Year 2018</h4>
                                <label for="budget">Budget:</label>
                                <input class="col-md-9" name="budget" disabled/>
                                <label for="balance">Balance:</label>
                                <input class="col-md-9" name="balance" disabled/>
                                <div class="space-top">
                                    <a href="monthly.html" class="btn btn-secondary">Details</a>
                                </div>
                            </blockquote>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-white bg-secondary">
                        <div class="card-body">
                            <blockquote class="card-blockquote">
                                <h2>February</h2>
                                <h4>Year 2018</h4>
                                <label for="budget">Budget:</label>
                                <input class="col-md-9" name="budget" disabled/>
                                <label for="balance">Balance:</label>
                                <input class="col-md-9" name="balance" disabled/>
                                <div class="space-top">
                                    <a href="monthly.html" class="btn btn-secondary">Details</a>
                                </div>
                            </blockquote>
                        </div>
                    </div>
                </div>

            </div>
            <div class="row space-top col-md-12">
                    <div class="col-md-3">
                        <div class="card text-white bg-secondary">
                            <div class="card-body">
                                <blockquote class="card-blockquote">
                                    <h2>March</h2>
                                    <h4>Year 2018</h4>
                                    <label for="budget">Budget:</label>
                                    <input class="col-md-9" name="budget" disabled/>
                                    <label for="balance">Balance:</label>
                                    <input class="col-md-9" name="balance" disabled/>
                                    <div class="space-top">
                                        <a href="monthly.html" class="btn btn-secondary">Details</a>
                                    </div>
                                </blockquote>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-white bg-secondary">
                            <div class="card-body">
                                <blockquote class="card-blockquote">
                                    <h2>April</h2>
                                    <h4>Year 2018</h4>
                                    <label for="budget">Budget:</label>
                                    <input class="col-md-9" name="budget" disabled/>
                                    <label for="balance">Balance:</label>
                                    <input class="col-md-9" name="balance" disabled/>
                                    <div class="space-top">
                                        <a href="monthly.html" class="btn btn-secondary">Details</a>
                                    </div>
                                </blockquote>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-white bg-secondary">
                            <div class="card-body">
                                <blockquote class="card-blockquote">
                                    <h2>May</h2>
                                    <h4>Year 2018</h4>
                                    <label for="budget">Budget:</label>
                                    <input class="col-md-9" name="budget" disabled/>
                                    <label for="balance">Balance:</label>
                                    <input class="col-md-9" name="balance" disabled/>
                                    <div class="space-top">
                                        <a href="monthly.html" class="btn btn-secondary">Details</a>
                                    </div>
                                </blockquote>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-white bg-secondary">
                            <div class="card-body">
                                <blockquote class="card-blockquote">
                                    <h2>June</h2>
                                    <h4>Year 2018</h4>
                                    <label for="budget">Budget:</label>
                                    <input class="col-md-9" name="budget" disabled/>
                                    <label for="balance">Balance:</label>
                                    <input class="col-md-9" name="balance" disabled/>
                                    <div class="space-top">
                                        <a href="monthly.html" class="btn btn-secondary">Details</a>
                                    </div>
                                </blockquote>
                            </div>
                        </div>
                    </div>
    
                </div>
                <div class="row space-top col-md-12">
                        <div class="col-md-3">
                            <div class="card text-white bg-secondary">
                                <div class="card-body">
                                    <blockquote class="card-blockquote">
                                        <h2>July</h2>
                                        <h4>Year 2018</h4>
                                        <label for="budget">Budget:</label>
                                        <input class="col-md-9" name="budget" disabled/>
                                        <label for="balance">Balance:</label>
                                        <input class="col-md-9" name="balance" disabled/>
                                        <div class="space-top">
                                            <a href="monthly.html" class="btn btn-secondary">Details</a>
                                        </div>
                                    </blockquote>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card text-white bg-secondary">
                                <div class="card-body">
                                    <blockquote class="card-blockquote">
                                        <h2>August</h2>
                                        <h4>Year 2018</h4>
                                        <label for="budget">Budget:</label>
                                        <input class="col-md-9" name="budget" disabled/>
                                        <label for="balance">Balance:</label>
                                        <input class="col-md-9" name="balance" disabled/>
                                        <div class="space-top">
                                            <a href="monthly.html" class="btn btn-secondary">Details</a>
                                        </div>
                                    </blockquote>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card text-white bg-secondary">
                                <div class="card-body">
                                    <blockquote class="card-blockquote">
                                        <h2>September</h2>
                                        <h4>Year 2018</h4>
                                        <label for="budget">Budget:</label>
                                        <input class="col-md-9" name="budget" disabled/>
                                        <label for="balance">Balance:</label>
                                        <input class="col-md-9" name="balance" disabled/>
                                        <div class="space-top">
                                            <a href="monthly.html" class="btn btn-secondary">Details</a>
                                        </div>
                                    </blockquote>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card text-white bg-secondary">
                                <div class="card-body">
                                    <blockquote class="card-blockquote">
                                        <h2>October</h2>
                                        <h4>Year 2018</h4>
                                        <label for="budget">Budget:</label>
                                        <input class="col-md-9" name="budget" disabled/>
                                        <label for="balance">Balance:</label>
                                        <input class="col-md-9" name="balance" disabled/>
                                        <div class="space-top">
                                            <a href="monthly.html" class="btn btn-secondary">Details</a>
                                        </div>
                                    </blockquote>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>

        );
    }
}