import React, { Component } from 'react';
import Input from '../common/Input';
import { register } from '../../api/remote';
import { validate } from './validation';

export default class RegisterPage extends Component {
    constructor(props) {
        super(props);

        this.state = {
            name: '',
            email: '',
            password: '',
            repeat: '',
            nameVal: "",
            emailVal: "",
            passwordVal: "",
            repeatVal: "",
            serverMsg: ""
        };

        this.onChangeHandler = this.onChangeHandler.bind(this);
        this.onSubmitHandler = this.onSubmitHandler.bind(this);
    }

    onChangeHandler(e) {
        this.setState({ [e.target.name]: e.target.value });
        let targetName = e.target.name;
        targetName = targetName + "Val"
        if (validate(e.target.name, e.target.value)) {
            this.setState({ [targetName]: true });
        } else {
            this.setState({ [targetName]: false })
        }

    }

    onSubmitHandler(e) {
        e.preventDefault();
        register(this.state.name, this.state.email, this.state.password)
            .then((res) => {
                this.setState({ serverMsg: res.message })
                if (res.success) {
                    setTimeout(() => {
                        this.props.history.push('/login')
                    }, 3000)

                }
            });
    }



    render() {

        return (
            <div className="container">
                <div className="row space-top">
                    <div className="col-md-12">
                        <h1>Register</h1>
                        <p>Please fill all fields.</p>

                        {this.state.serverMsg && <div className="alert alert-warning">{this.state.serverMsg}</div>}
                    </div>
                </div>
                <form onSubmit={this.onSubmitHandler}>
                    <div className="row">
                        <div className="col-md-3">
                            <div className="form-group">
                                <label className="form-control-label " htmlFor="new-username">Username</label>

                                <input className={this.state.nameVal ? "form-control is-valid" : "form-control is-invalid"} id="new-username" type="text"
                                    name="name"
                                    value={this.state.name}
                                    onChange={this.onChangeHandler}
                                />
                            </div>
                            <div className="form-group">
                                <label className="form-control-label" htmlFor="new-email">E-mail</label>
                                <input className={this.state.emailVal ? "form-control is-valid" : "form-control is-invalid"} id="new-email" type="text"
                                    name="email"
                                    value={this.state.email}
                                    onChange={this.onChangeHandler}
                                />
                                {/* <div className="form-control-feedback">This input value is valid</div> */}
                            </div>
                            <div className="form-group">
                                <label className="form-control-label" htmlFor="new-password">Password</label>
                                <input className={this.state.passwordVal ? "form-control is-valid" : "form-control is-invalid"} id="new-password" type="password"
                                    name="password"
                                    value={this.state.password}
                                    onChange={this.onChangeHandler}
                                />
                                {/* <div className="form-control-feedback">This input value is invalid</div> */}
                            </div>
                            <div className="form-group">
                                <label className="form-control-label" htmlFor="new-repeat-password">Repeat password</label>
                                <input className={this.state.repeatVal ? "form-control is-valid" : "form-control is-invalid"} id="new-repeat-password" type="password"
                                    name="repeat"
                                    value={this.state.repeat}
                                    onChange={this.onChangeHandler}
                                />
                                {/* <div className="form-control-feedback">This input value is invalid</div> */}
                            </div>
                            <input type="submit" className="btn btn-secondary" value="Register" />
                        </div>
                    </div>
                </form>
            </div>
        );
    }
}