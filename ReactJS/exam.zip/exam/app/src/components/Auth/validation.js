function validate(field, value) {
    switch (field) {
        case "name":
            if (value.length < 3) {
                return false;
            } else {
                return true;
            }
        case "email":
            if (/^[a-zA-Z0-9]+@[a-zA-Z0-9]+\.[A-Za-z]+$/.test(value)) {
                return true;
            } else {
                return false;
            }
        case "password":
            if (value.length < 4) {
                return false;
            } else {
                return true;
            }
        case "repeat":
            if (value.length < 4) {
                return false;
            } else {
                return true;
            }
        default:
            break;
    }
}

export { validate };