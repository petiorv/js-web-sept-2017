import React, { Component } from 'react';
import Input from '../common/Input';
import { login } from '../../api/remote';
import toastr from 'toastr'

export default class LoginPage extends Component {
    constructor(props) {
        super(props);

        this.state = {
            email: '',
            password: '',
            serverMsg: ''
        };

        this.onChangeHandler = this.onChangeHandler.bind(this);
        this.onSubmitHandler = this.onSubmitHandler.bind(this);
    }

    onChangeHandler(e) {
        this.setState({ [e.target.name]: e.target.value });
    }

    onSubmitHandler(e) {
        e.preventDefault();
        login(this.state.email, this.state.password).then(res=>{
            this.setState({serverMsg: res.message})
            if(res.success){
                localStorage.setItem('user', res.user.name)
                localStorage.setItem('token', res.token)
                toastr.success(res.message);
                this.props.history.push('/yearlyBalance')
            } else{
                toastr.error(res.message)
            }

            
            
        });
    }

    render() {
        return (
            <div className="container">
                <div className="row space-top">
                    <div className="col-md-12">
                        <h1>Login</h1>
                    </div>
                </div>
                {/* {this.state.serverMsg && <div className="alert alert-warning">{this.state.serverMsg}</div>} */}
                <form onSubmit={this.onSubmitHandler}>
                    <div className="row space-top">
                        <div className="col-md-3">
                            <div className="form-group">
                                <label className="form-control-label" htmlFor="email">E-mail</label>
                                <input className="form-control"
                                    name="email"
                                    value={this.state.email}
                                    onChange={this.onChangeHandler}                                
                                />
                            </div>
                            <div className="form-group">
                                <label className="form-control-label" htmlFor="password">Password</label>
                                <input className="form-control" id="password" type="password"
                                    name="password"
                                    value={this.state.password}
                                    onChange={this.onChangeHandler}
                                />
                            </div>
                            <input type="submit" className="btn btn-secondary" value="Login" />
                        </div>
                    </div>
                </form>
            </div>
        );
        // return (
        //     <div classNameName="container">
        //         <h1>Login</h1>
        //         <form onSubmit={this.onSubmitHandler}>
        //             <Input
        //                 name="email"
        //                 value={this.state.email}
        //                 onChange={this.onChangeHandler}
        //                 label="E-mail"
        //             />
        //             <Input
        //                 name="password"
        //                 type="password"
        //                 value={this.state.password}
        //                 onChange={this.onChangeHandler}
        //                 label="Password"
        //             />
        //             <input type="submit" classNameName="btn btn-primary" value="Login" />
        //         </form>
        //     </div>
        // );
    }
}