const homeHandler = require('./homeHandler');
const staticHandler = require('./static-files');

module.exports = [ homeHandler, staticHandler ];