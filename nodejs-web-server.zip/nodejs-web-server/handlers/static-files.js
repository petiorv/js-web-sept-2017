const fs = require('fs');
const url = require('url');
const filePath = './public/images/favicon.ico';

module.exports = (req, res) => {
    req.pathname = req.pathname || url.parse(req.url).pathname;
    if (req.pathname === '/favicon.ico' && req.method === 'GET') {
        fs.readFile(filePath, (err, data) => {
            if (err) {
                console.log(err)
                return;
            }

            res.writeHead(200, {
                'Content-Type': 'image/x-icon'
            })

            res.write(data);
            res.end();
        })
    } else if (req.pathname.startsWith('/public/') && req.method === 'GET') {
        fs.readFile('.' + req.pathname, (err, data) => {
            if (err) {
                console.log(err)
                return;
            }
            res.end();

        })
    } else {
        res.end();
    }
}