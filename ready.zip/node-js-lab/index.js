
let storage = require('./storage.js');


storage.put('fist', 1)
.then(() => {
  storage.put('second', 2)
    .then(() => {
      storage.put('third', 3)
        .then(() => {
          storage.save()
            .then(() => {
              storage.load()
                .then(() => {
                  storage.getAll();
                })
            })
        })
    })
})