
let storage = require('./storage.js');


storage.put('fist', "firstValue")
.then(() => {
  storage.put('second', "secondValue")
    .then(() => {
      storage.put('third', "thirdValue")
        .then(() => {
          storage.save()
            .then(() => {
              storage.load()
                .then(() => {
                  storage.getAll();
                })
            })
        })
    })
})