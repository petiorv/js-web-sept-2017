const fs = require('fs');
let db = {};

function isString(key) {
    if (typeof (key) === 'string') {
        return true;
    } else {
        return false;
    }
}

function isExist(key) {
    if (!db.hasOwnProperty(key)) {
        return true;
    } else {
        false;
    }
}

let put = (key, value) => {
    return new Promise((resolve, reject) => {
        if (!isString(key)) {
            reject(new Error('Key must be string!'));
        }
        if (!isExist(key)) {
            reject(new Error('Key already exist'));
        }

        resolve(db[key] = value);
    })

}

let get = (key) => {
    return new Promise((resolve, reject) => {
        if (isExist(key)) {
            reject(new Error('Key does not exist!'));
        }

        resolve(console.log(db[key]));
    })
}

let getAll = () => {
    return new Promise((resolve, reject) => {
        if (Object.values(db).lenght === 0) {
            reject(new Error('storage is empty!'));
        }

        resolve(console.log(db));
    });
}

let update = (key, newValue) => {
    return new Promise((resolve, reject) => {
        if (!isString(key)) {
            reject(new Error('Key is not string'));
        }

        if (isExist(key)) {
            reject(new Error('Key does not exist!'));
        }

        db[key] = newValue
        resolve();
    })

}

let deleteItem = (key) => {
    return new Promise((resolve, reject) => {
        if (!isString(key)) {
            reject(new Error('Key is not string!'))
        }

        if (isExist(key)) {
            reject(new Error('Key does not exist!'));
        }
        delete db[key];
        resolve();
    })

}

let clear = () => {
    return new Promise((resolve, reject) => {
        db = {};
        resolve();
    });
}

let save = () => {
    return new Promise((resolve, reject) => {
        fs.writeFile('./data.json', JSON.stringify(db), 'utf-8', (err, data) => {
            if (err) {
                return;
            }
            resolve();
        })
    })
}

let load = () => {
    return new Promise((resolve, reject) => {
        fs.readFile('./data.json', 'utf8', (err, data) => {
            if (err) {
                reject(err);
            }
            db = JSON.stringify(data);
            resolve();
        });
    });
}

module.exports = {
    put: put,
    get: get,
    getAll: getAll,
    update: update,
    delete: deleteItem,
    clear: clear,
    save: save,
    load: load
}