const fs = require('fs');
let db = {};

let isKey = (key) => {
    if (typeof(key) !== 'string') {
        throw new Error('Key must be a string!');
    }
};

let keyExists = (key) => {
    if (!db.hasOwnProperty(key)) {
        throw new Error(`Key doesn't exists!`);
    }
};

let put = (key, value) => {
    isKey(key);
    if (db.hasOwnProperty(key)) {
        throw new Error('Key already exists');
    }

    db[key] = value;
};

let get = (key) => {
    if (!db.hasOwnProperty(key)) {
        console.log(`Key doesn't exists!`);
        return;
    }

    return db[key];
};

let getAll = () => {
    if (Object.keys(db).length === 0) {
        return 'There are no items in the storage';
    }

    return db;
};

let update = (key, value) => {
    isKey(key);
    keyExists(key);
    db[key] = value;
};

let deleteItem = (key) => {
    isKey(key);
    keyExists(key);
    delete db[key];
};

let clear = () => {
    db = {};
};

let save = () => {
    fs.writeFileSync('./storage.json', JSON.stringify(db), 'utf8');
};

// Using synchronous file access
let load = () => {
    try {
        db = JSON.parse(fs.readFileSync('./storage.json', 'utf8'));
    } catch (err) {
    } finally {
    }
};

// // Using asynchronous file access
// let load = (callback) => {
//     fs.readFile('./storage.json', 'utf8', ((err, data) => {
//         if (err) {
//             return;
//         }
//
//         db = JSON.parse(data);
//
//         callback();
//     }))
// };

module.exports = {
  put: put,
  get: get,
  getAll: getAll,
  update: update,
  delete: deleteItem,
  clear: clear,
  save: save,
  load: load
};