
const ADD_COUNTER = 'ADD_COUNTER';
const REMOVE_COUNTER = 'REMOVE_COUNTER';
const INCREMENT = 'INCREMENT';
const DECREMENT = 'DECREMENT';
const CLEAR = 'CLEAR';


export default  actionObj = {
    addCounter: () => {
        return { type: ADD_COUNTER };
    },
    removeCounter: () => {
        return { type: REMOVE_COUNTER };
    },
    incrementCounter: (payload) => {
        return { type: INCREMENT, payload };
    },
    decremetnCounter: (payload) => {
        return { type: DECREMENT, payload };
    },
    clearCounter: (payload) => {
        return { type: CLEAR, payload };
    }
};