export default (store = [], action) => {
    switch (action.type) {
        case 'INCREMENT':
            console.log(action);
            return [...store.slice(0, action.payload.index),
            Object.assign({}, store[action.payload.index],
                {
                    value: store[action.payload.index].value + action.payload.step
                }),
            ...store.slice(action.payload.index + 1)
            ];
        case 'DECREMENT':
            console.log('decrement');
            return [...store.slice(0, action.payload.index),
            Object.assign({}, store[action.payload.index],
                {
                    value: store[action.payload.index].value - action.payload.step
                }),
            ...store.slice(action.payload.index + 1)
            ];
        case 'CLEAR':
            console.log(action);
            return [...store.slice(0, action.payload.index),
            Object.assign({}, store[action.payload.index],
                {
                    value: 0
                }),
            ...store.slice(action.payload.index + 1)
            ];
        case 'ADD_COUNTER':
            return [...store, { index: store.length, value: 0 }];
        case 'REMOVE_COUNTER':
            return [...store.slice(0, store.length - 1)];
        default:
            return store;
    }
};
