import React, { Component } from 'react';

let Counter = (props) => {
    return (
        <div>
            <h1>{props.props.value}</h1>
            <button onClick={() => {
                store.dispatch(actionObj.incrementCounter({ index: props.props.index, step: 1 }))
            }}>Increment</button>
            <button onClick={() => {
                store.dispatch(actionObj.decremetnCounter({ index: props.props.index, step: 1 }))
            }}>Decrement</button>
            <button onClick={()=>{
                store.dispatch(actionObj.clearCounter({index: props.props.index}))
            }}>Clear</button>
        </div>
    );
}

export default Counter;