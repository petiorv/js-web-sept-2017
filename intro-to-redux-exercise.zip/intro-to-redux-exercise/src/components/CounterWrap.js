import React, {Components} from 'react';
import Counter from './Counter';

 const mapStateToProps = function(state){
    return {
        something: state,
    }
 }

 const mapDispatchToProps = function(dispatch){
     return{
         loadCourses: () =>{
             dispatch(addInput())
         },
         change: ()=>{
             dispatch({type: 'TOGGLE', id:1})
         }
     }
 }

let CounterWrap = () => {
    return (
        <div>
            {store.getState().map(counter => {
                return <Counter key={counter.index} props={counter} />
            })}
            <button onClick={() => {
                store.dispatch(actionObj.addCounter())
            }}>Add Counter</button>
            <button onClick={() => {
                store.dispatch(actionObj.removeCounter())
            }}>Delete Counter</button>
        </div>
    );
}

export default connect(mapStateToProps, mapDispatchToProps)(CounterWrap);