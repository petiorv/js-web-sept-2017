import React, { Component } from 'react';

class Register extends Component {
    constructor() {
        super();
        
        this.dataCollector = (e) => {            
            this.setState({ [e.target.name]: e.target.value });
            //DataCollector(e);
        }
        
        this.Register = (e) =>{
            e.preventDefault();
            console.log(this.state.password)
            fetch('https://baas.kinvey.com/user/kid_Bk2jtkPyf/', {
                method: 'POST',
                headers: {
                    Authorization: 'Basic ' + btoa('kid_Bk2jtkPyf:e6becd9881124877bac235752a67040a'),
                    'Content-Type': 'application/json'

                },
                body: JSON.stringify({ 'username' :  this.state.username, 'password': this.state.password})

            }).then(res => {
                return res.json();
            }).then(parsedData =>{
                console.log(parsedData);             
            });
            console.log(this.state);
        } 
    }

    render() {
        return (
            <form id="registerForm" onSubmit={(e) => {this.Register(e)}}>                
                <h2>Register</h2>
                <label>Username:</label>
                <input onChange={(e) => { this.dataCollector(e) }} name="username" type="text" />
                <label>Password:</label>
                <input onChange={(e) => { this.dataCollector(e) }} name="password" type="password" />
                <label>Repeat Password:</label>
                <input onChange={(e) => { this.dataCollector(e) }} name="repeatPass" type="password" />
                <input id="btnRegister" value="Sign Up" type="submit" />
            </form>
        );
    }
}

export default Register;