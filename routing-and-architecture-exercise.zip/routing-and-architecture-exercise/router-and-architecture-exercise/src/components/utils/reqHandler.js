import React, { Component } from 'react';
const appKey = 'kid_Bk2jtkPyf';
const appSecret = 'e6becd9881124877bac235752a67040a';
const hostUrl = 'https://baas.kinvey.com';


let reqHandler = {
    login: (payload) => {
        return fetch(`${hostUrl}/user/${appKey}/login`, {
            method: 'POST',
            headers: {
                Authorization: 'Basic ' + btoa(`${appKey}:${appSecret}`),
                'Content-Type': 'application/json'

            },
            body: JSON.stringify(payload)

        }).then(res => {
            return res.json();
        });
    }
};

export default reqHandler;
