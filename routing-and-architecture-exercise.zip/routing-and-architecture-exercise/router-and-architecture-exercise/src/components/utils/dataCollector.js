export default e => {
    this.setState({ [e.target.name]: e.target.value });
};