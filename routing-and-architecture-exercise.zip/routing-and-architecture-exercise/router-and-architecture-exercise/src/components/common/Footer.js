import React from 'react';

let Footer = () => {
    return (
        <footer>SeenIt SPA © 2017</footer>
    );
}

export default Footer;