import React, { Component } from 'react';

export default class RegisterPage extends Component {
    render() {
        const { type, name, value, onChange, labe } = this.props;
        return (
            <div className="form-group">
                <label className="form-control-label" htmlFor="new-email">E-mail</label>
                <input className="form-control is-valid"
                    onChange={onChange}
                    name={name}
                    id={name}
                    type={type}
                    value={value}
                />
                {false && <div className="form-control-feedback">This input value is valid</div>}
            </div >
        );
    }
}