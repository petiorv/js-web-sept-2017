import React, { Component } from 'react';

export default class LoginPage extends Component{
    render() {
        return (
            <h1>Login Page</h1>
        );
    }
}