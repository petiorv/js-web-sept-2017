import React, { Component } from 'react';

export default class DetailsPage extends Component{
    render() {
        return (
            <h1>Details Page</h1>
        );
    }
}