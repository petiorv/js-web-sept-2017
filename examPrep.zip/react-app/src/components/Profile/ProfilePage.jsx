import React, { Component } from 'react';

export default class ProfilePage extends Component{
    render() {
        return (
            <h1>Profile Page</h1>
        );
    }
}