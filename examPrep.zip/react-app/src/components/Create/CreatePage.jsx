import React, { Component } from 'react';

export default class CreatePage extends Component{
    render() {
        return (
            <h1>Create Page</h1>
        );
    }
}