const data = require('./form-data');

module.exports = {
    data
};