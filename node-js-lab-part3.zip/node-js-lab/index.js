const http = require('http');
const url = require('url');
const handlers = require('./handlers');
let environment = process.env.NODE_ENV || 'development';
const config = require('./config/config');
const database = require('./config/database.config');
const port = 2525;

database(config[environment]);

http.createServer((req, res) => {
    req.pathname = req.pathname || url.parse(req.url).pathname; 
    for (let handler of handlers) {
        if (!handler(req, res)) {
            break;
        }
    }
}).listen(port);

console.log(`Listening on ${port}...`);