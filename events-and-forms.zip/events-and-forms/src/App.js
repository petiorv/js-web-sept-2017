import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import ToggleButton from './components/ToggleButton';
import DivFocus from './components/focusDiv';
import Form from './components/Form/Form';
import Converter from './components/Converter/Converter';

class App extends Component {
  render() {
    return (
      <div className="App">    
        <Converter />    
        <Form />
        <ToggleButton />
        <p className="App-intro">
          To get started, edit <code>src/App.js</code> and save to reload.
        </p>

        
        <DivFocus  number='1'/>
        <DivFocus  number='2'/>
        <br/>
        <DivFocus  number='3'/>
        <DivFocus  number='4'/>
        
      </div>
    );
  }
}

export default App;
