const mongoose = require('mongoose');
const path = 'mongodb://localhost:27017/memedb';

mongoose.Promise = global.Promise;

module.exports = (() => {
    mongoose.createConnection(path, {
        useMongoClient: true
    });
    console.log('connected to db!');
})();