const fs = require('fs');
const Tag = require('../models/TagSchema');
const Image = require('../models/ImageSchema');

let loadHtml = (res, images) => {
  console.log(images);
  fs.readFile('views/results.html', (err, html) => {
    if (err) {
      console.log(err);
      return;
    }
    let resultString = '';
    for (let singleImage of images) {
      resultString += `<fieldset id => <legend>${singleImage.imageTitle}:</legend> 
                       <img src="${singleImage.imageUrl}">
                       </img><p>${singleImage.description}<p/>
                       <button onclick='location.href="/delete?id=${singleImage._id}"'class='deleteBtn'>Delete
                       </button> 
                       </fieldset>`;
    }
    html = html.toString()
      .replace("<div class='replaceMe'></div>", resultString);
    res.writeHead(200, {
      'Content-Type': 'text/html'
    });
    res.write(html);
    res.end();
  });
};

let showAll = (req, res) => {
  Image.find({}).then((images) => {
    loadHtml(res, images);
  }).catch((err) => {
    console.log(err);
    return;
  });
};

let filteredSearch = (req, res) => {

  let beforeDate = req.pathquery.beforeDate;
  let afterDate = req.pathquery.afterDate;
  let minDate = new Date(afterDate);
  let maxDate = new Date(beforeDate);
  console.log(maxDate + '______________________' + minDate);
  let limit = Number(req.pathquery.Limit);

  if (limit === 0) {
    limit = 10;
  }

  let tags = req.pathquery.tagName;
  let tagArr = [];
  if (tags.indexOf(',') > -1) {
    tagArr = tags.split(', ');
  } else {
    tagArr.push(tags);
  }
  Tag.find({
    tagName: { $in: tagArr }
  }).then((tags) => {
    let tagIds = [];
    for (let tag of tags) {
      tagIds.push(tag.id);
    }
    Image
      .find({ tags: { $in: tagIds } })
      .sort({ date: -1 })
      .then((images) => {
        if (beforeDate && afterDate) {
          images = images.filter(d => d.dateC > minDate && d.date < maxDate);          
        }
        if (!beforeDate && afterDate) {
          images = images.filter(d => d.dateC > minDate);
        }
        if (beforeDate && !afterDate) {
          images = images.filter(d => d.dateC < maxDate);
        }
        loadHtml(res, images);
      }).catch((e) => {
        console.log(e);
        return;
      });

  }).catch((e) => {
    console.log(e);
    return;
  });
};

module.exports = (req, res) => {

  if (req.pathname === '/search') {
    if (req.pathquery.tagName !== "Write tags separted by ,") {
      filteredSearch(req, res);
    } else {
      showAll(req, res);
    }
  } else {
    return true;
  }
};
